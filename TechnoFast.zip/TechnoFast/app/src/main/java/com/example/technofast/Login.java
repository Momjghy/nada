package com.example.technofast;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {

    TextInputEditText tname, tpass;
    MaterialTextView terror;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        tname = findViewById(R.id.tname);
        tpass = findViewById(R.id.tpass);
        terror = findViewById(R.id.txterror);

    }

    public void login(View view) {
        String username = tname.getText().toString().trim();
        String pass = tpass.getText().toString().trim();

        ProgressDialog progressDialog = new ProgressDialog(Login.this);
        progressDialog.setMessage("يتم تحميل البيانات");

        if (username.isEmpty())
            terror.setText("أدخل الاسم");
        else if (pass.isEmpty())
            terror.setText("أدخل كلمة المرور");
        else {
            terror.setText("");
            progressDialog.show();
            StringRequest stringRequest = new StringRequest(Request.Method.POST,
                    "http://192.168.208.204/courses/login.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONArray jsonArray = new JSONArray(response);
                        if (jsonArray.length() > 0) {
                            Toast.makeText(getApplicationContext(), "مرحبا بك", Toast.LENGTH_SHORT).show();
                            Intent MainIntent = new Intent(Login.this, MainActivity.class);
                            startActivity(MainIntent);
                        } else {
                            terror.setText("اسم المستخدم أو كلمة المرور خطأ");
                        }
                        progressDialog.dismiss();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "خطأ: " + e.toString(), Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "خطأ: " + error.toString(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> data = new HashMap<>();
                    data.put("name", username);
                    data.put("pass", pass);

                    return data;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(Login.this);
            requestQueue.add(stringRequest);
        }
    }
}