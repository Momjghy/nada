package com.example.technofast;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class HomeAdapter extends ArrayAdapter<HomeListView> {

    Context context;
    List<HomeListView> arraylistView;

    public HomeAdapter(@NonNull Context context, List<HomeListView> arraylistView) {
        super(context, R.layout.listviewhome,arraylistView);
        this.context=context;
        this.arraylistView = arraylistView;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView , @NonNull ViewGroup parent){

        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.listviewhome,null,true);
        TextView tname= view.findViewById(R.id.coname);
        TextView  tpairod =view.findViewById(R.id.cotime);
        TextView  tprice =view.findViewById(R.id.coprice);

        tname.setText(arraylistView.get(position).getName());
        tpairod.setText(arraylistView.get(position).getTime());
        tprice.setText(arraylistView.get(position).getPrice());

        return view;
    }
}

