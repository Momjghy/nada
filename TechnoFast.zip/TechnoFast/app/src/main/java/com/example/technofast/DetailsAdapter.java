package com.example.technofast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class DetailsAdapter extends ArrayAdapter<DetailsListView> {

        Context context;
        List<DetailsListView> arraylistView;

        public DetailsAdapter(@NonNull Context context, List<DetailsListView> arraylistView) {
                super(context, R.layout.listsetails,arraylistView);
                this.context=context;
                this.arraylistView = arraylistView;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView , @NonNull ViewGroup parent){

                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.listsetails,null,true);

                TextView  tname= view.findViewById(R.id.coname);
                TextView  tpairod =view.findViewById(R.id.cotime);
                TextView  tprice =view.findViewById(R.id.coprice);
                TextView  tdetails=view.findViewById(R.id.codetail);

                tname.setText(arraylistView.get(position).getName());
                tpairod.setText(arraylistView.get(position).getTime());
                tprice.setText(arraylistView.get(position).getPrice());
                tdetails.setText(arraylistView.get(position).getDetails());

                return view;
        }
}
