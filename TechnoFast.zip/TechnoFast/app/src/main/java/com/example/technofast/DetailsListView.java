package com.example.technofast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DetailsListView  {

    private String id,name,time,price,details;

    public DetailsListView( String coid,String coname, String cotime, String coprice, String codetails) {
        this.id = coid;
        this.name = coname;
        this.time = cotime;
        this.price = coprice;
        this.details=codetails;
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime()
    {
        return time;
    }

    public void setTime(String time)
    {
        this.time = time;
    }

    public String getPrice()
    {
        return price;
    }

    public void setPrice(String price)
    {
        this.price = price;
    }

    public String getDetails()
    {
        return details;
    }

    public void setDetails(String details)
    {
        this.details = details;
    }
}
