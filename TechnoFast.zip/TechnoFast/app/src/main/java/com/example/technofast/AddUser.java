package com.example.technofast;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;

import java.util.HashMap;
import java.util.Map;

public class AddUser extends AppCompatActivity {


    TextInputEditText tname, tpass;
    MaterialTextView terror;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);

        tname = findViewById(R.id.tname);
        tpass = findViewById(R.id.tpass);
        terror = findViewById(R.id.txterror);
    }

    public void Add(View view) {
        String username = tname.getText().toString().trim();
        String pass = tpass.getText().toString().trim();

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("يتم الآن تسجيل البيانات");

        if (username.isEmpty())
            terror.setText("أدخل الاسم");
        else if (pass.isEmpty())
            terror.setText("أدخل كلمة المرور");
        else {
            progressDialog.show();

            StringRequest stringRequest = new StringRequest(Request.Method.POST,
                    "http://192.168.208.204/courses/addUsers.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    progressDialog.dismiss();
                    tname.setText("");
                    tpass.setText("");

                    show_alert();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                    Toast.makeText(AddUser.this, " لم يتم التسجيل " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> data = new HashMap<String, String>();
                    data.put("name", username);
                    data.put("pass", pass);

                    return data;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(AddUser.this);
            requestQueue.add(stringRequest);
        }
    }

    public void show_alert() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle("تسجيل");
        builder.setMessage("تم  تسجيلك  بنجاح ");

        builder.setPositiveButton("موافق", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent MainIntent = new Intent(AddUser.this, MainActivity.class);
                startActivity(MainIntent);
            }
        });
        builder.create().show();
    }

    public void goLogin(View view) {
        Intent LoginIntent = new Intent(this, Login.class);
        startActivity(LoginIntent);
    }
}

