package com.example.technofast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;

public class MainActivity extends AppCompatActivity {

    TextInputEditText tname,tpass;
    MaterialTextView terror;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tname=findViewById(R.id.tname);
        tpass=findViewById(R.id.tpass);
        terror=findViewById(R.id.txterror);
    }

    public void btnGraphics(View view) {
        Intent intent=new Intent(this, Home.class);
        intent.putExtra("codecousre", "1");
        startActivity(intent);
    }

    public void btnPrograms(View view) {
        Intent intent=new Intent(this,Home.class);
        intent.putExtra("codecousre", "2");
        startActivity(intent);
    }

    public void btnNetwork(View view) {

        // startActivity(new Intent(MainActivity.this, Home.class));
        Intent intent=new Intent(this,Home.class);
        intent.putExtra("codecousre", "3");
        startActivity(intent);
    }

    public void btnMobile(View view) {
        Intent intent=new Intent(this,Home.class);
        intent.putExtra("codecousre", "4");
        startActivity(intent);
    }
}