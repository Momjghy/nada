package com.example.technofast;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Home extends AppCompatActivity {

    ListView listHome;
    HomeAdapter homeAdapter;
    public static ArrayList<HomeListView> homeArrayList = new ArrayList<>();
    HomeListView homeListView;

    String url_listview = "http://192.168.208.204/courses/getDataCourses.php";
    String code, id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        listHome = findViewById(R.id.listHome);
        homeAdapter = new HomeAdapter(this, homeArrayList);
        listHome.setAdapter(homeAdapter);

        Intent intcode = getIntent();
        code = intcode.getExtras().getString("codecousre");

        listHome.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                HomeListView r = (HomeListView) listHome.getItemAtPosition(i);
                id = r.getId();

                Intent intent = new Intent((Context) Home.this, Details.class);
                intent.putExtra("id", id);
                Home.this.startActivity(intent);
            }
        });
        ShowHome();
    }

    private void ShowHome() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("يتم تحميل البيانات");
        progressDialog.show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_listview, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                homeArrayList.clear();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String courseid = object.getString("Id").trim();
                            String coursename = object.getString("Name").trim();
                            String coursetime = object.getString("Time").trim();
                            String courseprice = object.getString("Price").trim();

                            homeListView = new HomeListView(courseid,coursename, coursetime, courseprice);
                            homeArrayList.add(homeListView);
                            homeAdapter.notifyDataSetChanged();
                        }
                    }
                    progressDialog.dismiss();
                } catch (JSONException e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                    Toast.makeText(Home.this, "خطأ: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(Home.this, "خطأ: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> data = new HashMap<String, String>();
                data.put("code", code);
                return data;
            }
        };


        RequestQueue requestQueue = Volley.newRequestQueue(Home.this);
        requestQueue.add(stringRequest);
    }


}
