package com.example.technofast;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Details extends AppCompatActivity {

    ListView listDetails;
    DetailsAdapter detailsAdapter;
    public static ArrayList<DetailsListView> detailsArrayList = new ArrayList<>();
    DetailsListView detailsListView;

    String url_listview = "http://192.168.208.204/courses/getDataCoursesDetails.php";
    TextInputEditText tn, tp;
    MaterialTextView terror;
    Button btreg;

    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        tn = findViewById(R.id.tsna);
        tp = findViewById(R.id.tsphon);
        terror = findViewById(R.id.txterror);
        btreg = findViewById(R.id.btnRg);

        Intent intid = getIntent();
        id = intid.getExtras().getString("id");

        listDetails = findViewById(R.id.listDetails);
        detailsAdapter = new DetailsAdapter(this, detailsArrayList);
        listDetails.setAdapter(detailsAdapter);

        ShowDetails();
    }

    public void Register(View view) {
        Intent intent = new Intent(this, Regis.class);
        intent.putExtra("id", id);
        startActivity(intent);
    }

    private void ShowDetails() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("يتم تحميل البيانات");
        progressDialog.show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                url_listview, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                detailsArrayList.clear();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if (success.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String courseid = object.getString("Id").trim();
                            String coursename = object.getString("Name").trim();
                            String coursetime = object.getString("Time").trim();
                            String courseprice = object.getString("Price").trim();
                            String coursedetails = object.getString("Details").trim();
                            detailsListView = new DetailsListView(courseid, coursename, coursetime, courseprice, coursedetails);
                            detailsArrayList.add(detailsListView);
                            detailsAdapter.notifyDataSetChanged();
                        }
                    }
                    progressDialog.dismiss();
                } catch (JSONException e) {
                    progressDialog.dismiss();
                    e.printStackTrace();
                    Toast.makeText(Details.this, "خطأ: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(Details.this, "خطأ: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> data = new HashMap<String, String>();
                data.put("id", id);
                return data;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Details.this);
        requestQueue.add(stringRequest);
    }
}