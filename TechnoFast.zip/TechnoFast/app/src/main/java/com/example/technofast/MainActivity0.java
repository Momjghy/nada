package com.example.technofast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity0 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main0);
    }
    public void goLogin(View view) {
        Intent LoginIntent =new Intent(this, Login.class);
        startActivity(LoginIntent);
    }

    public void goAddUser(View view) {
        Intent AddUserIntent =new Intent(this, AddUser.class);
        startActivity(AddUserIntent);
    }

    public void goExit(View view) {
        finish();
    }
}